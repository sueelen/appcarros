import 'package:flutter/material.dart';

// ignore: must_be_immutable
class AppButton extends StatefulWidget {
  Function onPressed;
  String text;


  AppButton(this.onPressed, this.text);

  @override
  _AppButtonState createState() => _AppButtonState();
}

class _AppButtonState extends State<AppButton> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      child: RaisedButton(
        color: Colors.lightGreen,
        child: Text(
          widget.text,
          style: TextStyle(color: Colors.white, fontSize: 23),),
        onPressed: widget.onPressed,
      ),
    );
  }
}

