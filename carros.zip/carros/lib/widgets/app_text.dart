import 'package:flutter/material.dart';

class AppText extends StatelessWidget {

  String label;
  String hint;
  bool password;
  TextEditingController controller;
  FormFieldValidator<String> validator;


  AppText(this.label, this.hint, {this.password = false, this.controller, this.validator,});

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      validator: (String text){
        if(text.isEmpty){
          return "Digite o texto";
        }
        if (text. length < 3){
          return "No minimo 3 digítos";
        }
        return null;
      },

      controller: controller,
      obscureText: password,
      style: TextStyle(color: Colors.black45, fontSize: 20),
      decoration: InputDecoration(
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16)
        ),
        labelText: label,
        labelStyle: TextStyle(color: Colors.black54, fontSize: 25),
        hintText: hint,
        hintStyle: TextStyle(color: Colors.black45, fontSize: 18),
      ),
    );
  }
}
