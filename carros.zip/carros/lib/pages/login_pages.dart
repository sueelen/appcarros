import 'package:flutter/cupertino.dart';
import 'package:carros/pages/home_page.dart';
import 'package:carros/utils/dart/nav.dart';
import 'package:carros/widgets/app_text.dart';
import 'package:flutter/material.dart';

class LoginPages extends StatelessWidget {
  final _formKey = GlobalKey<FormState>();
  final _tlogin = TextEditingController();
  final _tsenha = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Carros"),
      ),
      body: _body(),
    );
  }

  _body() {
    return Form(
      key: _formKey,
      child: Container(
        padding: EdgeInsets.all(17),
        child: ListView(
          children: <Widget>[
            AppText("Login", "Digite seu usuário",
                controller: _tlogin, validator: _validateLogin),
            SizedBox(
              height: 10,
            ),
            AppText("Senha", "Digite sua senha",
                password: true, controller: _tsenha, validator: _validateSenha),
            SizedBox(
              height: 20,
            ),
            _button("Login", onClickLogin),
          ],
        ),
      ),
    );
  }

  _button(String text, Function onPressed) {
    return Container(
      height: 50,
      child: RaisedButton(
        color: Colors.lightGreen,
        child: Text(
          text,
          style: TextStyle(color: Colors.white, fontSize: 23),
        ),
        onPressed: onPressed,
      ),
    );
  }


  void onClickLogin() {
    if (!_formKey.currentState.validate()) {
      return;
    }
    String login = _tlogin.text;
    String senha = _tsenha.text;

    print("Login: $login, Senha $senha");

     push(context, HomePage());

  }

// ignore: missing_return
  String _validateLogin(String text) {
// ignore: unnecessary_statements
    (String text) {
      if (text.isEmpty) {
        return "Digite o login";
      }
      return null;
    };
  }
}

// ignore: missing_return
String _validateSenha(String text) {
// ignore: unnecessary_statements
  (String text) {
    if (text.isEmpty) {
      return "Digite a senha";
    }
    if (text.length < 3) {
      return "No minimo 3 digítos";
    }
    return null;
  };
}
